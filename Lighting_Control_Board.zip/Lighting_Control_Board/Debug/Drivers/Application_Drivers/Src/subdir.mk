################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (11.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/Application_Drivers/Src/ADC.c \
../Drivers/Application_Drivers/Src/CAN.c \
../Drivers/Application_Drivers/Src/CCS.c \
../Drivers/Application_Drivers/Src/I2C.c \
../Drivers/Application_Drivers/Src/Indicate.c \
../Drivers/Application_Drivers/Src/SPI.c \
../Drivers/Application_Drivers/Src/Temp.c \
../Drivers/Application_Drivers/Src/UART.c \
../Drivers/Application_Drivers/Src/boost.c \
../Drivers/Application_Drivers/Src/clock.c 

OBJS += \
./Drivers/Application_Drivers/Src/ADC.o \
./Drivers/Application_Drivers/Src/CAN.o \
./Drivers/Application_Drivers/Src/CCS.o \
./Drivers/Application_Drivers/Src/I2C.o \
./Drivers/Application_Drivers/Src/Indicate.o \
./Drivers/Application_Drivers/Src/SPI.o \
./Drivers/Application_Drivers/Src/Temp.o \
./Drivers/Application_Drivers/Src/UART.o \
./Drivers/Application_Drivers/Src/boost.o \
./Drivers/Application_Drivers/Src/clock.o 

C_DEPS += \
./Drivers/Application_Drivers/Src/ADC.d \
./Drivers/Application_Drivers/Src/CAN.d \
./Drivers/Application_Drivers/Src/CCS.d \
./Drivers/Application_Drivers/Src/I2C.d \
./Drivers/Application_Drivers/Src/Indicate.d \
./Drivers/Application_Drivers/Src/SPI.d \
./Drivers/Application_Drivers/Src/Temp.d \
./Drivers/Application_Drivers/Src/UART.d \
./Drivers/Application_Drivers/Src/boost.d \
./Drivers/Application_Drivers/Src/clock.d 


# Each subdirectory must supply rules for building sources it contributes
Drivers/Application_Drivers/Src/%.o Drivers/Application_Drivers/Src/%.su Drivers/Application_Drivers/Src/%.cyclo: ../Drivers/Application_Drivers/Src/%.c Drivers/Application_Drivers/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DSTM32 -DSTM32F1 -DSTM32F103C8Tx -c -I../Inc -I"C:/Users/Jack Herron/git/STM32_Skipper_Development/Lighting_Control_Board/Drivers/Application_Drivers/Inc" -I"C:/Users/Jack Herron/git/STM32_Skipper_Development/Lighting_Control_Board/Drivers/CMSIS/Device/ST/STM32F1xx/Include" -I"C:/Users/Jack Herron/git/STM32_Skipper_Development/Lighting_Control_Board/Drivers/CMSIS/Include" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Drivers-2f-Application_Drivers-2f-Src

clean-Drivers-2f-Application_Drivers-2f-Src:
	-$(RM) ./Drivers/Application_Drivers/Src/ADC.cyclo ./Drivers/Application_Drivers/Src/ADC.d ./Drivers/Application_Drivers/Src/ADC.o ./Drivers/Application_Drivers/Src/ADC.su ./Drivers/Application_Drivers/Src/CAN.cyclo ./Drivers/Application_Drivers/Src/CAN.d ./Drivers/Application_Drivers/Src/CAN.o ./Drivers/Application_Drivers/Src/CAN.su ./Drivers/Application_Drivers/Src/CCS.cyclo ./Drivers/Application_Drivers/Src/CCS.d ./Drivers/Application_Drivers/Src/CCS.o ./Drivers/Application_Drivers/Src/CCS.su ./Drivers/Application_Drivers/Src/I2C.cyclo ./Drivers/Application_Drivers/Src/I2C.d ./Drivers/Application_Drivers/Src/I2C.o ./Drivers/Application_Drivers/Src/I2C.su ./Drivers/Application_Drivers/Src/Indicate.cyclo ./Drivers/Application_Drivers/Src/Indicate.d ./Drivers/Application_Drivers/Src/Indicate.o ./Drivers/Application_Drivers/Src/Indicate.su ./Drivers/Application_Drivers/Src/SPI.cyclo ./Drivers/Application_Drivers/Src/SPI.d ./Drivers/Application_Drivers/Src/SPI.o ./Drivers/Application_Drivers/Src/SPI.su ./Drivers/Application_Drivers/Src/Temp.cyclo ./Drivers/Application_Drivers/Src/Temp.d ./Drivers/Application_Drivers/Src/Temp.o ./Drivers/Application_Drivers/Src/Temp.su ./Drivers/Application_Drivers/Src/UART.cyclo ./Drivers/Application_Drivers/Src/UART.d ./Drivers/Application_Drivers/Src/UART.o ./Drivers/Application_Drivers/Src/UART.su ./Drivers/Application_Drivers/Src/boost.cyclo ./Drivers/Application_Drivers/Src/boost.d ./Drivers/Application_Drivers/Src/boost.o ./Drivers/Application_Drivers/Src/boost.su ./Drivers/Application_Drivers/Src/clock.cyclo ./Drivers/Application_Drivers/Src/clock.d ./Drivers/Application_Drivers/Src/clock.o ./Drivers/Application_Drivers/Src/clock.su

.PHONY: clean-Drivers-2f-Application_Drivers-2f-Src

